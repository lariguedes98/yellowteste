<h2>
    <a href="https://yellowweb.top/donate" target="_blank">
        Version: 29.05.2024
        <br />
        PHP: <?= PHP_VERSION ?>
        <br /> Please, donate!
    </a>
</h2>
