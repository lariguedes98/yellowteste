<?php

namespace Sinergi\BrowserDetector;

class InvalidArgumentException extends \InvalidArgumentException
{
}
