<?php

namespace Sinergi\BrowserDetector;

interface DetectorInterface
{
}
