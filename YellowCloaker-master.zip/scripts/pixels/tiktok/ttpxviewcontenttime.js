<script>
// Delay pixel fire
var ttseconds = {SECONDS};
setTimeout(function() {
  ttq.track('ViewContent');
}, ttseconds * 1000);
</script>