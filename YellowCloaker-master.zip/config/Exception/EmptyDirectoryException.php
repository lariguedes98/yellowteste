<?php

namespace Noodlehaus\Exception;

use Noodlehaus\Exception;

class EmptyDirectoryException extends Exception
{
}
